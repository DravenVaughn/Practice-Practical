#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "pico/stdlib.h"
#include "support.h"

// Base library headers ncluded for your convenience.
// ** You may have to add more depending on your practical. **
#include "hardware/gpio.h"
#include "hardware/irq.h"
#include "hardware/timer.h"
#include "hardware/adc.h"
#include "hardware/dma.h"
#include "hardware/pwm.h"
#include "hardware/spi.h"
#include "hardware/uart.h"
#include "pico/rand.h"

void grader();

//////////////////////////////////////////////////////////////////////////////

// Make sure to set your pins if you are using this on your own breadboard.
// For the Platform Test Board, these are the correct pin numbers.
const int SPI_7SEG_SCK = 14;
const int SPI_7SEG_CSn = 13;
const int SPI_7SEG_TX = 15;

// NOT NEEDED since we are not using LCD/OLED in this practical.
// But it needs to be defined to avoid compiler errors.
const int SPI_DISP_SCK = -1;
const int SPI_DISP_CSn = -1;
const int SPI_DISP_TX = -1;

// Remember this from ECE 270?
// Verilog borrowed this from C.
typedef enum {
    INIT = 0,
    READY = 1,
    REACT = 2,
    RESULT = 3
} reactor_state_t;
reactor_state_t reactor_state = INIT;

// Track which button was last pressed.
int last_pressed = -1;

//////////////////////////////////////////////
// Step 1

void reaction_isr() {
    // fill in
}

void init_reaction_irq() {
    // fill in
}

//////////////////////////////////////////////
//// Step 2. 

uint16_t __attribute__((aligned(16))) message[8] = {
    (0 << 8) | 0x3F,    // seven-segment value of 0
    (1 << 8) | 0x06,    // seven-segment value of 1
    (2 << 8) | 0x5B,    // seven-segment value of 2
    (3 << 8) | 0x4F,    // seven-segment value of 3
    (4 << 8) | 0x66,    // seven-segment value of 4
    (5 << 8) | 0x6D,    // seven-segment value of 5
    (6 << 8) | 0x7D,    // seven-segment value of 6
    (7 << 8) | 0x07,    // seven-segment value of 7
};
// 7-segment display font mapping
extern char font[];

void sevenseg_display(const char* str) {
    // fill in
}

void init_sevenseg_spi() {
    // fill in
}

//////////////////////////////////////////////
//// Step 3. 

uint32_t last_set_time = 0;

void timer_isr() {
    // fill in   
}

void init_reaction_timer() {
    // fill in
}

//////////////////////////////////////////////
//// Step 4. 

void init_sevenseg_dma() {
    // fill in
}

//////////////////////////////////////////////////////////////////////////////

// There is no need to modify main() unless you want to add debugging output.

// The only exception may be to disable the grader() call if you think it's 
// interfering with your functionality, somehow.

int main()
{
    stdio_init_all();
    
    grader();

    init_reaction_irq();
    init_sevenseg_spi();
    init_sevenseg_dma();

    for(;;) {
        sevenseg_display("READY? ");
        sio_hw->gpio_hi_clr = (1 << (38 - 32)); // blue on
        int seed = get_rand_32() % 5;
        // between 2 and 7 seconds.
        sleep_ms(2000 + (seed * 1000));

        if (last_pressed != -1) {
            // they messed up and pressed button too early
            sevenseg_display("FAIL   !");
            sio_hw->gpio_hi_set = (1 << (38 - 32)); // blue off
            sio_hw->gpio_hi_clr = (1 << (37 - 32)); // red on
            sleep_ms(3000);
            sio_hw->gpio_hi_set = (1 << (37 - 32)); // red off
            last_pressed = -1;
            reactor_state = READY;
            continue;
        }

        // set the pushbutton wanted and then change state
        int want = (get_rand_32() % 2) ? 21 : 26;
        sio_hw->gpio_hi_set = (1 << (38 - 32)); // blue off
        reactor_state = REACT;
        if (want == 26) {
            sevenseg_display("PRESS  L");
        } else {
            sevenseg_display("PRESS  R");
        }
        init_reaction_timer();

        // wait for pushbutton or timer interrupt
        while (reactor_state != RESULT);

        // At this point, either pushbuttons or timer woke us up.
        // Find out what.
        if (reactor_state == RESULT) {
            // correct button
            if (last_pressed == want) {
                uint64_t now = timer_hw->timerawl;

                sevenseg_display("PASS");
                sio_hw->gpio_hi_clr = (1 << (39 - 32)); // green on
                sleep_ms(1000);
                
                // show diff in time
                float diff = (now - last_set_time) / 1000.00;
                char buf[9];
                snprintf(buf, sizeof(buf), "%3.3f", diff);
                sevenseg_display(buf);
                sleep_ms(2000);
            }
            else {
                sevenseg_display("FAIL");
                sio_hw->gpio_hi_clr = (1 << (37 - 32)); // red on 
            }
        }
        sleep_ms(3000);
        sio_hw->gpio_hi_set = (1 << (37 - 32)) | (1 << (39 - 32)); // red and green off
        last_pressed = -1;
        reactor_state = READY;
    }

    for(;;);
    return 0;
}