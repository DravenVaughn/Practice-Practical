# PlatformIO extra script: adds a "Grade" task (project tasks -> proton -> Custom -> Grade, or
# `pio run -t grade`).  It uploads src/*.c to the grading server, which builds it with the genuine
# grader, flashes the result to the connected board over SWD, and reports the grader's verdict.
Import("env")
import os, sys

TOOLS = os.path.join(env["PROJECT_DIR"], "tools")


def _session_code():
    """Normally none: students grade on their own.  Only if the course turns on session codes
    (server option) does a student need to set one, in platformio.ini or the environment."""
    code = os.environ.get("ECE362_SESSION") or env.GetProjectOption("custom_session_code", "")
    return code.strip().upper()


def grade(target, source, env):
    # SCons restores sys.path once this script has loaded, so the import path must be set here,
    # when the action actually runs.
    if TOOLS not in sys.path:
        sys.path.insert(0, TOOLS)
    from gradelib import DEFAULT_AUTH, DEFAULT_URL, auth
    from gradelib.run import run_grade, GradeError
    project_dir = env["PROJECT_DIR"]
    platform = env.PioPlatform()
    ocd_dir = platform.get_package_dir("tool-openocd-rp2040-earlephilhower") or ""
    protocol = env.subst("$UPLOAD_PROTOCOL") or "picoprobe"
    args = env.BoardConfig().get("debug.tools.%s.server.arguments" % protocol, [])
    exe = os.path.join(ocd_dir, "bin", "openocd.exe" if sys.platform == "win32" else "openocd")
    session = _session_code()
    opts = {
        "url": os.environ.get("ECE362_BOARDRUN_URL") or env.GetProjectOption("custom_boardrun_url", DEFAULT_URL),
        "practical": env.GetProjectOption("custom_practical"),
        "project_dir": project_dir,
        "work_dir": os.path.join(project_dir, ".pio", "grade"),
        "session_code": session,
        "ocd_exe": exe,
        "ocd_args": [a.replace("$PACKAGE_DIR", ocd_dir) for a in args],
        "speed": int(env.GetProjectOption("debug_speed", "5000") or 5000),
        "token_provider": lambda api: auth.get_identity(
            api, os.environ.get("ECE362_AUTH") or env.GetProjectOption("custom_auth", DEFAULT_AUTH)),
    }
    try:
        res = run_grade(opts)
    except GradeError as e:
        print("\nGrade stopped: %s" % e)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled.")
        return 1
    return 0


env.AddCustomTarget(
    name="grade",
    dependencies=None,
    actions=[env.Action(grade, None)],          # None: do not echo grade(["grade"], []) into the output
    title="Grade",
    description="Build on the grading server, flash the board, and grade your practical",
    always_build=True,
)
