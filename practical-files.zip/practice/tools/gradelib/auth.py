"""Login: browser device-code flow, token cached in the OS keyring.

Purdue login needs Duo, so no password ever passes through this script.  The terminal prints a code,
the student approves it in the browser (behind Purdue CAS), and the server hands back a signed token
valid for 24 hours.  The token is stored in the OS keyring (Windows Credential Manager, macOS Keychain,
Linux Secret Service); if no keyring backend is usable it falls back to a 0600 file in the home
directory, and if even that fails the student simply logs in again next time.
"""
import getpass, json, os, stat, subprocess, sys, threading, time, webbrowser

from .api import Api, ApiError

KEYRING_TIMEOUT = 8.0         # seconds a keyring call may take before we give up on it (a locked
                              # Secret Service can block forever behind a dialog nobody sees)
_keyring_dead = False         # set once a keyring call has timed out: don't wait on it again this run


def say(text):
    """print() that is flushed immediately, so a slow step never looks like a hang."""
    sys.stdout.write(text + "\n")
    sys.stdout.flush()


def _timed(fn, *args, default=None):
    """Run a keyring call with a time limit.  Returns default if it raises or does not answer in time."""
    global _keyring_dead
    if _keyring_dead:
        return default
    result = {}

    def target():
        try:
            result["v"] = fn(*args)
        except Exception:
            result["err"] = True
    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(KEYRING_TIMEOUT)
    if t.is_alive():
        _keyring_dead = True
        say("The OS keyring did not answer (is it locked? check for an unlock window). "
            "Continuing without it; your login will not be saved this time.")
        return default
    return default if "err" in result else result.get("v", default)


SERVICE = "ece362-grader"
ACCOUNT = "token"
FALLBACK = os.path.join(os.path.expanduser("~"), ".ece362", "grader-token.json")


def _keyring():
    """Return the keyring module with a real backend, installing it on first use; else None."""
    try:
        import keyring
    except ImportError:
        say("Installing the 'keyring' package (one time, needs internet; this can take a minute)...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "keyring"],
                           check=True, timeout=180)
            import keyring
        except Exception:
            say("Could not install 'keyring'; your login will not be saved.")
            return None
    try:
        name = keyring.get_keyring().__class__.__module__
        if name.startswith("keyring.backends.fail") or name.startswith("keyring.backends.null"):
            return None
    except Exception:
        return None
    return keyring


def _load():
    kr = _keyring()
    if kr:
        try:
            raw = kr.get_password(SERVICE, ACCOUNT)
            if raw:
                return json.loads(raw)
        except Exception:
            pass
    try:
        with open(FALLBACK) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _store(blob):
    raw = json.dumps(blob)
    kr = _keyring()
    if kr:
        try:
            kr.set_password(SERVICE, ACCOUNT, raw)
            return "keyring"
        except Exception:
            pass
    try:
        os.makedirs(os.path.dirname(FALLBACK), exist_ok=True)
        fd = os.open(FALLBACK, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(raw)
        return "file"
    except OSError:
        return "none"


def forget():
    kr = _keyring()
    if kr:
        try:
            kr.delete_password(SERVICE, ACCOUNT)
        except Exception:
            pass
    try:
        os.unlink(FALLBACK)
    except OSError:
        pass


def login(api: Api, out=print, open_browser=webbrowser.open, sleep=time.sleep):
    """Run the device-code flow and return {"token", "user", "expires"}."""
    _, start = api.post("/api/v1/device/start", {})
    out("")
    out("Sign in with your Purdue account to continue.")
    out("  Code:  %s" % start["user_code"])
    out("  Open:  %s" % start["verification_url"])
    out("Check that the page shows the SAME code before you approve it.")
    try:
        open_browser(start["verification_url"])
    except Exception:
        pass                                    # headless / remote: the URL above is enough
    deadline = time.time() + start.get("expires_in", 600)
    while time.time() < deadline:
        sleep(start.get("interval", 2))
        try:
            status, body = api.post("/api/v1/device/poll", {"device_code": start["device_code"]})
        except ApiError as e:
            if e.status == 410:
                break
            raise
        if status == 200 and body.get("token"):
            blob = {"token": body["token"], "user": body["user"], "expires": body["expires"]}
            where = _store(blob)
            out("Signed in as %s (credentials kept in the %s)." % (body["user"], {
                "keyring": "OS keyring", "file": "file ~/.ece362/grader-token.json", "none": "this session only"}[where]))
            return blob
    raise ApiError(0, "login timed out; run Grade again")


def get_token(api: Api, out=print, **kw):
    """Use the cached token if the server still accepts it, else log in again."""
    blob = _load()
    if blob and blob.get("expires", 0) > time.time() + 60:
        api.token = blob["token"]
        try:
            api.get("/api/v1/me")
            return blob
        except ApiError as e:
            if e.status != 401:
                raise
    blob = login(api, out=out, **kw)
    api.token = blob["token"]
    return blob


# ---------------------------------------------------------------------------------------------
# HTTP Basic mode: the web server authenticates the Purdue username/password itself and tells the
# app who it is (REMOTE_USER).  The password is cached in the OS keyring, never in a file on disk; in the practical VM,
# which has no keyring daemon, it is kept in a RAM-only file in $XDG_RUNTIME_DIR until the VM shuts down; if
# there is no keyring backend, the student is asked again each run.
# ---------------------------------------------------------------------------------------------
BASIC_SERVICE = "ece362-grader-basic"
BASIC_ACCOUNT = "credentials"


def _is_tmpfs(path):
    """True if path lives on a RAM-backed (tmpfs) filesystem, i.e. nothing written there reaches a disk."""
    try:
        real, best, fstype = os.path.realpath(path), "", ""
        with open("/proc/mounts") as f:
            for line in f:
                parts = line.split()
                mnt = parts[1].replace("\\040", " ")
                if (real == mnt or real.startswith(mnt.rstrip("/") + "/")) and len(mnt) >= len(best):
                    best, fstype = mnt, parts[2]
        return fstype == "tmpfs"
    except Exception:
        return False


def _ram_file():
    """Where the practical VM keeps the login for this session: a 0600 file in the user's tmpfs runtime folder.
    None anywhere else (a student's own computer has a real keyring), or if that folder is not private RAM."""
    try:
        if getpass.getuser() != GUI_USER:
            return None
        d = os.environ.get("XDG_RUNTIME_DIR", "")
        st = os.stat(d)
        if not d or st.st_uid != os.getuid() or stat.S_IMODE(st.st_mode) & 0o077 or not _is_tmpfs(d):
            return None
        return os.path.join(d, BASIC_SERVICE + ".json")
    except Exception:
        return None


def _ram_load():
    path = _ram_file()
    try:
        st = os.stat(path)
        if st.st_uid != os.getuid() or stat.S_IMODE(st.st_mode) & 0o077:
            return None
        with open(path) as f:
            d = json.load(f)
        return d["user"], d["password"]
    except Exception:
        return None


def _ram_store(user, password):
    path = _ram_file()
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump({"user": user, "password": password}, f)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def _basic_load():
    kr = _keyring()
    if kr:
        raw = _timed(kr.get_password, BASIC_SERVICE, BASIC_ACCOUNT)
        if raw:
            try:
                d = json.loads(raw)
                return d["user"], d["password"]
            except (ValueError, KeyError):
                pass
        return None
    return _ram_load()


def _basic_store(user, password):
    """Returns "keyring" or "session" (RAM only) when the login was kept, else False."""
    kr = _keyring()
    if kr:
        ok = _timed(lambda: (kr.set_password(BASIC_SERVICE, BASIC_ACCOUNT,
                                             json.dumps({"user": user, "password": password})), True)[1],
                    default=False)
        return "keyring" if ok else False
    return "session" if _ram_store(user, password) else False


def forget_basic():
    kr = _keyring()
    if kr:
        try:
            kr.delete_password(BASIC_SERVICE, BASIC_ACCOUNT)
        except Exception:
            pass
    path = _ram_file()
    if path:
        try:
            os.remove(path)
        except OSError:
            pass


def _ask(prompt):
    """Ask a question as a COMPLETE line, then read the answer from the next line.

    PlatformIO relays a task's output to the terminal line by line and holds back a partial line, so a
    prompt like "Username: " (no newline) stays invisible until the student presses Enter, which looks
    like a hang.  Only a newline-terminated prompt is shown immediately.
    """
    say(prompt.rstrip())
    line = sys.stdin.readline()
    if not line:
        raise EOFError
    return line.rstrip("\r\n")


GUI_DIALOGS = [os.path.join(os.path.dirname(os.path.abspath(__file__)), "login_dialog.py"),   # shipped in the practical zip
               "/usr/local/bin/prac-login-dialog"]                                              # older VM images have it built in
GUI_USER = "ecelabprac"                           # the practical VM's student account


def _gui_dialog():
    return next((p for p in GUI_DIALOGS if os.path.exists(p)), None)


def _gui_available():
    """True inside the practical VM with a desktop: there a sign-in window replaces the terminal prompts."""
    try:
        return (os.environ.get("DISPLAY") and _gui_dialog() and getpass.getuser() == GUI_USER
                and os.path.exists("/usr/bin/python3"))
    except Exception:
        return False


def _gui_ask(error=""):
    """Show the sign-in window.  Returns (user, password); None if cancelled; False if it cannot be shown."""
    cmd = ["/usr/bin/python3", _gui_dialog()] + (["--error", error] if error else [])
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, universal_newlines=True, timeout=900)
    except Exception:
        return False
    if r.returncode == 1:
        return None
    try:
        d = json.loads(r.stdout)
        return d["user"].split("@")[0].lower(), d["password"]
    except (ValueError, KeyError):
        return False


def get_basic(api: Api, out=print, interactive=True, input_fn=_ask, getpass_fn=getpass.getpass, tries=3, gui=None):
    """Authenticate with Purdue credentials over HTTP Basic.  Returns {"user": ...}."""
    use_gui = _gui_available() if gui is None else gui
    last_error = ""
    say("Looking for saved Purdue credentials in the OS keyring...")
    creds = _basic_load()
    env_user, env_pw = os.environ.get("ECE362_USER"), os.environ.get("ECE362_PASSWORD")
    if env_user and env_pw:
        creds = (env_user, env_pw)
    from_cache = creds is not None
    for attempt in range(tries + 1):
        if creds is None:
            if not interactive:
                raise ApiError(401, "not signed in; run Grade once from the terminal to sign in")
            if attempt >= tries:
                break
            got = _gui_ask(last_error) if use_gui else False
            if got is None:
                raise ApiError(401, "sign-in cancelled; run Grade again to sign in")
            if got is False:
                use_gui = False                       # no window possible: ask in the terminal instead
                say("No saved login. Sign in with your Purdue career account "
                    "(the password is never written to disk).")
                try:
                    user = input_fn("Purdue username (type it and press Enter):").strip().lower()
                    say("Password (what you type will not be shown):")
                    password = getpass_fn("")
                except EOFError:
                    raise ApiError(401, "no terminal to ask for a password; set ECE362_USER and ECE362_PASSWORD")
                got = (user.split("@")[0], password)
            creds = got
            from_cache = False
        api.basic = creds
        say("Signing in to the grading server as %s..." % creds[0])
        try:
            _, me = api.get("/api/v1/me", timeout=30)
        except ApiError as e:
            if e.status != 401:
                raise
            last_error = ("That username/password was not accepted." if not from_cache else
                          "The saved credentials no longer work (password changed?).")
            out(last_error)
            if from_cache:
                forget_basic()
            creds, api.basic = None, None
            continue
        if not from_cache:
            kept = _basic_store(*creds)
            out("Signed in as %s%s." % (me["user"], {"keyring": " (saved in the OS keyring)",
                                                  "session": " (remembered until this VM is shut down)"}.get(kept) or
                                       " (no keyring available: you will be asked again next time)"))
        return {"user": me["user"], "expires": None}
    raise ApiError(401, "could not sign in after %d attempts" % tries)


def get_identity(api: Api, mode="basic", out=print, interactive=True, **kw):
    """The one entry point the Grade and Publish scripts use: mode is "basic" or "token"."""
    if mode == "basic":
        return get_basic(api, out=out, interactive=interactive, **kw)
    if mode == "token":
        if interactive:
            return get_token(api, out=out, **kw)
        blob = _load()
        if not blob:
            raise ApiError(401, "not signed in; run Grade once from the terminal to sign in")
        api.token = blob["token"]
        return blob
    raise ValueError("custom_auth must be 'basic' or 'token', not %r" % mode)
