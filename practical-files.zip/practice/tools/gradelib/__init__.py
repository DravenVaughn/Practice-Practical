"""Client for the ECE 362 practical grader (used by the Grade target in tools/grade.py)."""
CLIENT_VERSION = "1"
DEFAULT_URL = "https://engineering.purdue.edu/ece362/boardrun/index.wsgi"
DEFAULT_AUTH = "basic"        # "basic" = Purdue username/password via the web server; "token" = browser sign-in
