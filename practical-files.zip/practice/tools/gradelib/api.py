"""Tiny JSON-over-HTTPS client (standard library only; works in PlatformIO's bundled Python)."""
import base64, json, urllib.error, urllib.parse, urllib.request


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


class Api:
    def __init__(self, base_url, token=None, timeout=60, basic=None):
        self.base = base_url.rstrip("/")
        self.token = token
        self.basic = basic                      # (username, password) for HTTP Basic, or None
        self.timeout = timeout

    def _url(self, path):
        """The hosting serves index.wsgi at the directory URL and routes by query string, so
        "/api/v1/build?x=1" becomes "<base>?op=build&x=1" (or "<base>/?op=..." for a directory URL)."""
        path, _, query = path.partition("?")
        op = path[len("/api/v1/"):] if path.startswith("/api/v1/") else path.lstrip("/")
        # A bare directory URL only runs index.* files Apache lists in DirectoryIndex, which .wsgi is not
        # by default, so the default base names the script itself (".../index.wsgi") and needs no "/".
        sep = "?" if self.base.endswith(".wsgi") else "/?"
        return "%s%sop=%s%s" % (self.base, sep, urllib.parse.quote(op, safe="/._-"), "&" + query if query else "")

    def _request(self, method, path, data=None, content_type=None, timeout=None):
        req = urllib.request.Request(self._url(path), data=data, method=method)
        if content_type:
            req.add_header("Content-Type", content_type)
        if self.basic:
            req.add_header("Authorization", "Basic " + base64.b64encode(
                ("%s:%s" % self.basic).encode("utf-8")).decode())
        elif self.token:
            req.add_header("Authorization", "Bearer " + self.token)
        try:
            with urllib.request.urlopen(req, timeout=timeout or self.timeout) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as e:
            body = e.read()
            try:
                message = json.loads(body).get("error", "")
            except ValueError:
                message = body[:200].decode("utf-8", "replace")
            raise ApiError(e.code, message or e.reason)
        except urllib.error.URLError as e:
            raise ApiError(0, "cannot reach the grading server: %s" % e.reason)

    def post(self, path, obj, timeout=None):
        status, body = self._request("POST", path, json.dumps(obj).encode(), "application/json", timeout)
        return status, json.loads(body or b"{}")

    def get(self, path, timeout=None):
        status, body = self._request("GET", path, timeout=timeout)
        return status, json.loads(body or b"{}")

    def get_bytes(self, path, timeout=None):
        return self._request("GET", path, timeout=timeout)[1]
