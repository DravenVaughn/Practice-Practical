"""The Grade workflow: upload source -> server builds -> flash -> watch the board -> report."""
import base64, glob, os, struct, sys, time

from . import CLIENT_VERSION
from .api import Api, ApiError
from .ocd import OpenOCD, OcdError


class GradeError(Exception):
    pass


def collect_sources(project_dir):
    """Every top-level src/*.c, as {name: text}.  The server decides which of them count."""
    files = {}
    for path in sorted(glob.glob(os.path.join(project_dir, "src", "*.c"))):
        with open(path, "rb") as f:
            raw = f.read()
        try:
            files[os.path.basename(path)] = raw.decode("utf-8")
        except UnicodeDecodeError:
            raise GradeError("%s is not valid UTF-8 text" % os.path.basename(path))
    if not files:
        raise GradeError("no .c files found in src/")
    return files


def build_remote(api, practical, files, session_code, out):
    out("Uploading %s to the grading server..." % ", ".join(sorted(files)))
    try:
        for attempt in range(5):
            try:
                _, info = api.post("/api/v1/build", {"practical": practical, "files": files,
                                                     "session_code": session_code, "client": CLIENT_VERSION})
                break
            except ApiError as e:
                if e.status != 503 or attempt == 4:         # 503 = the server is busy: wait a moment and try again
                    raise
                wait = 3 * (attempt + 1)
                out("The grading server is busy; trying again in %d seconds..." % wait)
                time.sleep(wait)
    except ApiError as e:
        if "session code" in e.message.lower():
            raise GradeError(e.message + "  Add custom_session_code = <code> to platformio.ini.")
        raise GradeError(e.message)
    if info.get("ignored"):
        out("Note: %s %s not graded and was ignored." % (", ".join(info["ignored"]),
                                                       "is" if len(info["ignored"]) == 1 else "are"))
    if not info["ok"]:
        out(info["log"])
        raise GradeError("Your code did not compile; fix the errors above and run Grade again.")
    if info["log"].strip():
        out(info["log"])                                  # warnings
    out("Built in %.1f s." % info["seconds"])
    return info


def watch(ocd, info, out, timeout, sleep=time.sleep, now=time.time):
    """Poll the report struct over SWD, echoing new transcript text, until the grader finishes.

    Returns (raw report bytes, finished).
    """
    lay, addr = info["report"], info["report_addr"]
    off, ring, magic = lay["offsets"], lay["log_size"], lay["magic"]
    u32 = lambda b, o: struct.unpack_from("<I", b, o)[0]
    seen, boots, started_seen = 0, 0, False
    deadline = now() + timeout
    while now() < deadline:
        hdr = ocd.read(addr, off["log"])
        if u32(hdr, off["magic"]) != magic:
            sleep(0.3)                                    # grader has not started yet
            continue
        cur_boots, head = u32(hdr, off["boots"]), u32(hdr, off["log_head"])
        if started_seen and (cur_boots != boots or head < seen):
            out("\n--- the board was reset (a test hung or crashed it); the grader restarted ---\n")
            seen = 0
        started_seen, boots = True, cur_boots
        if head > seen:
            log = ocd.read(addr + off["log"], ring)
            start = max(seen, head - ring)
            text = bytes(log[i % ring] for i in range(start, head)).decode("utf-8", "replace")
            out(text, end="")
            seen = head
        if u32(hdr, off["state"]) == lay["states"]["done"] and u32(hdr, off["end_magic"]) == magic:
            return ocd.read(addr, lay["size"]), True
        sleep(0.25)
    return ocd.read(addr, lay["size"]), False


def run_grade(opts, out=None, sleep=time.sleep):
    """opts: url, practical, project_dir, session_code, ocd_exe, ocd_args, speed, token_provider."""
    def emit(text, end="\n"):
        sys.stdout.write(text + end)
        sys.stdout.flush()
    out = out or emit
    api = Api(opts["url"])
    try:
        blob = opts["token_provider"](api)
    except ApiError as e:
        raise GradeError("sign-in failed: %s" % e.message)
    out("Grading as %s." % blob["user"])

    files = collect_sources(opts["project_dir"])
    info = build_remote(api, opts["practical"], files, opts["session_code"], out)
    elf_path = os.path.join(opts["work_dir"], "grade-%s.elf" % info["job_id"])
    os.makedirs(opts["work_dir"], exist_ok=True)
    with open(elf_path, "wb") as f:
        f.write(api.get_bytes(info["elf_url"], timeout=120))

    lay, addr = info["report"], info["report_addr"]
    ocd = OpenOCD(opts["ocd_exe"], opts["ocd_args"], speed=opts["speed"], port=opts.get("port", 6666))
    try:
        out("Flashing the board (keep it connected)...")
        verified = ocd.start(elf_path, clear_words=(addr + lay["offsets"]["magic"],
                                                    addr + lay["offsets"]["end_magic"]))
        out("Flash verified." if verified else "WARNING: OpenOCD did not report a verified flash.")
        out("Running the grader on your board...\n")
        live = []                                   # the board's own log: shown if the server cannot be reached
        raw, finished = watch(ocd, info, lambda t, end="": live.append(t + end), info["run_timeout_s"], sleep=sleep)
    except OcdError as e:
        raise GradeError("could not talk to the board: %s" % e)
    finally:
        ocd.close()
        try:
            os.unlink(elf_path)
        except OSError:
            pass

    if not finished:
        out("\nThe grader did not finish within %d s; sending what it produced." % info["run_timeout_s"])
    try:
        _, res = api.post("/api/v1/result", {"job_id": info["job_id"], "flash_verified": verified,
                                             "report_b64": base64.b64encode(raw).decode()})
    except ApiError as e:
        out("".join(live))
        raise GradeError("the server rejected the result: " + e.message)
    out("")
    if res.get("output"):                           # the grader's output exactly as it always looked, with the points
        out(res["output"])
    else:                                           # an older server: at least the points
        for s in res["steps"]:
            out("Step %s: %d/%d" % (s["name"], s["score"], s["max"]))
            for line in s.get("messages", []):
                out("  %s" % line)
        out("Final score: %d/%d" % (res["total"], res["total_max"]))
    out("")
    board = res.get("board") or {}
    msg = {"new": "Board %s registered to you.", "known": "Board %s recognised as yours.",
           "additional": "Board %s is a NEW board for you (you already registered a different one).",
           "conflict": "WARNING: board %s is registered to a different student. Use your own board.",
           "invalid": "Could not read a valid board ID (%s)."}.get(board.get("status"))   # "unchecked": say nothing
    if msg:
        out(msg % board.get("serial"))
    if not res["recorded"]:
        out("\nThis run was NOT recorded as a pass (grader unfinished, results inconsistent, or the "
            "flash could not be verified). Fix the problem and run Grade again.")
    if res["recorded"]:
        out("Note: your most recent completed run is the one that counts, even if an earlier run scored higher.")
        out("Your result has been recorded." if res.get("delivery") != "pending" else
            "Your result has been recorded. It could not reach the course system just now and will be delivered "
            "automatically in a moment; you do not need to do anything.")
    return res
