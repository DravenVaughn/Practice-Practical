"""Drive the OpenOCD that PlatformIO already ships: flash an ELF, then read RAM while it runs.

Only a fixed set of operations is ever issued (program/verify, reset, read RAM, clear two words,
shutdown) and the commands are built here, never taken from the server.  In particular nothing
here touches OTP, debug-disable or secure-boot settings.
"""
import os, shutil, socket, subprocess, tempfile, threading, time

TERM = b"\x1a"          # OpenOCD's Tcl RPC message terminator


class OcdError(Exception):
    pass


class TclRpc:
    def __init__(self, port, timeout=30):
        self.sock = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        self.sock.settimeout(timeout)

    def call(self, command):
        self.sock.sendall(command.encode() + TERM)
        data = b""
        while not data.endswith(TERM):
            chunk = self.sock.recv(65536)
            if not chunk:
                raise OcdError("OpenOCD closed the connection")
            data += chunk
        return data[:-1].decode("utf-8", "replace")

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


def _tcl_path(path):
    return "{" + path.replace("\\", "/") + "}"


class OpenOCD:
    def __init__(self, exe, args, speed=5000, port=6666, startup_timeout=90):
        self.exe, self.args, self.speed, self.port = exe, list(args), speed, port
        self.startup_timeout = startup_timeout
        self.proc, self.rpc, self.output = None, None, []
        self.tmp = tempfile.mkdtemp(prefix="grade-")

    # -------------------------------------------------------------------- start / flash

    def start(self, elf, clear_words=()):
        """Flash `elf` (verified), clear `clear_words` (addresses), and let the board run.

        Returns True if OpenOCD reported "Verified OK".  Clearing the report's magic words matters:
        RAM survives a reset, so without it we could read the previous run's finished report.
        """
        cmd = [self.exe] + self.args + [
            "-c", "adapter speed %d" % self.speed,
            "-c", "tcl_port %d" % self.port, "-c", "gdb_port disabled", "-c", "telnet_port disabled",
            "-c", "init",
            "-c", "program %s verify" % _tcl_path(elf),
            "-c", "reset init"]
        for addr in clear_words:
            cmd += ["-c", "mww 0x%08x 0" % addr]
        cmd += ["-c", "resume"]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        threading.Thread(target=self._pump, daemon=True).start()
        # The Tcl port opens only after the -c commands above have finished, so a successful
        # connection means: flashed, verified, reset, running.
        deadline = time.time() + self.startup_timeout
        while time.time() < deadline:
            if self.proc.poll() is not None:
                raise OcdError("OpenOCD exited while flashing:\n" + self.log_tail())
            try:
                self.rpc = TclRpc(self.port)
                break
            except OSError:
                time.sleep(0.25)
        else:
            raise OcdError("timed out waiting for OpenOCD to flash the board:\n" + self.log_tail())
        text = "\n".join(self.output)
        if "Verify Failed" in text or "** Programming Failed **" in text:
            raise OcdError("flashing failed:\n" + self.log_tail())
        return "** Verified OK **" in text

    def _pump(self):
        for line in self.proc.stdout:
            self.output.append(line.decode("utf-8", "replace").rstrip())

    def log_tail(self, n=25):
        return "\n".join(self.output[-n:])

    # -------------------------------------------------------------------- RAM reads

    def read(self, addr, size, retries=8, delay=0.4):
        """Read RAM.

        Retries: a watchdog reset (which the grader uses to recover from hung student code) drops
        the SWD link for a moment; OpenOCD re-establishes it but fails the read that was in flight.
        """
        path = os.path.join(self.tmp, "dump.bin")
        last = ""
        for _ in range(retries):
            if os.path.exists(path):
                os.unlink(path)
            last = self.rpc.call("dump_image %s 0x%x %d" % (_tcl_path(path), addr, size)).strip()
            if os.path.exists(path) and os.path.getsize(path) == size:
                with open(path, "rb") as f:
                    return f.read()
            time.sleep(delay)
        raise OcdError("could not read %d bytes at 0x%x after %d tries: %s\n%s"
                       % (size, addr, retries, last, self.log_tail(8)))

    def close(self):
        if self.rpc:
            try:
                self.rpc.call("shutdown")
            except Exception:
                pass
            self.rpc.close()
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        shutil.rmtree(self.tmp, ignore_errors=True)
