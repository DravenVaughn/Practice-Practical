#!/usr/bin/python3
# Purdue sign-in window for the Grade task (run by tools/gradelib/auth.py inside the practical VM).
# usage: prac-login-dialog [--error "message"] [--user name]
# Prints {"user": ..., "password": ...} as JSON on success (exit 0); exit 1 if the student cancels.
import argparse, json, re, subprocess, sys, tkinter as tk
from tkinter import font as tkfont

ap = argparse.ArgumentParser()
ap.add_argument("--error", default="")
ap.add_argument("--user", default="")
a = ap.parse_args()

root = tk.Tk()
root.title("ECE 36200 Grader Sign-in")
root.resizable(False, False)
base = tkfont.nametofont("TkDefaultFont"); base.configure(size=13)
tkfont.nametofont("TkTextFont").configure(size=13)
root.option_add("*Font", base)

frame = tk.Frame(root, padx=28, pady=22); frame.pack()
tk.Label(frame, text="Sign in to the grader", font=(base.actual("family"), 18, "bold")).grid(row=0, column=0, columnspan=2, sticky="w")
tk.Label(frame, text="Use your Purdue career account (the same login as Brightspace).\nIt is saved in this session's keyring so you only enter it once.",
         justify="left").grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 14))
err = tk.Label(frame, text=a.error, fg="#c00000", justify="left", wraplength=460)
err.grid(row=2, column=0, columnspan=2, sticky="w", pady=(0, 8 if a.error else 0))
if not a.error: err.grid_remove()

tk.Label(frame, text="Username").grid(row=3, column=0, sticky="w", pady=4)
user = tk.StringVar(value=a.user); ue = tk.Entry(frame, textvariable=user, width=28); ue.grid(row=3, column=1, pady=4, padx=(14, 0))
tk.Label(frame, text="Password").grid(row=4, column=0, sticky="w", pady=4)
pw = tk.StringVar(); pe = tk.Entry(frame, textvariable=pw, width=28, show="•"); pe.grid(row=4, column=1, pady=4, padx=(14, 0))
show = tk.IntVar(value=0)
tk.Checkbutton(frame, text="Show password", variable=show,
               command=lambda: pe.config(show="" if show.get() else "•")).grid(row=5, column=1, sticky="w", padx=(10, 0))

def ok(_=None):
    if not user.get().strip() or not pw.get():
        err.config(text="Enter both your username and password."); err.grid(); return
    print(json.dumps({"user": user.get().strip(), "password": pw.get()})); root.destroy()

def cancel(_=None):
    root.destroy(); sys.exit(1)

btns = tk.Frame(frame); btns.grid(row=6, column=0, columnspan=2, sticky="e", pady=(18, 0))
tk.Button(btns, text="Cancel", width=10, command=cancel).pack(side="right", padx=(10, 0))
tk.Button(btns, text="Sign in", width=10, command=ok, default="active").pack(side="right")
root.bind("<Return>", ok); root.bind("<Escape>", cancel); root.protocol("WM_DELETE_WINDOW", cancel)

def parse_monitors(query, listing):
    """[(is_primary, x, y, w, h)] from `xrandr --query` (connected outputs) or, failing that, `xrandr --listmonitors`."""
    mons = []
    for m in re.finditer(r"^\S+ connected (primary )?(\d+)x(\d+)\+(-?\d+)\+(-?\d+)", query, re.M):
        mons.append((bool(m.group(1)), int(m.group(4)), int(m.group(5)), int(m.group(2)), int(m.group(3))))
    if not mons:
        for m in re.finditer(r"^\s*\d+:\s+(\S+)\s+(\d+)/\d+x(\d+)/\d+\+(-?\d+)\+(-?\d+)", listing, re.M):
            mons.append(("*" in m.group(1), int(m.group(4)), int(m.group(5)), int(m.group(2)), int(m.group(3))))
    return mons


def pick(mons, screen_w, screen_h):
    """(x, y, w, h) of the monitor to centre on: the primary one, else the leftmost; a screen that is far wider than it is
    tall (two monitors reported as one) is cut in half so the window lands on its left monitor."""
    if mons:
        x, y, w, h = sorted(mons, key=lambda t: (not t[0], t[1], t[2]))[0][1:]
    else:
        x, y, w, h = 0, 0, screen_w, screen_h
    if w > 2.2 * h:
        w //= 2
    return x, y, w, h


def primary_monitor():
    def xrandr(arg):
        try:
            return subprocess.run(["xrandr", arg], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  universal_newlines=True, timeout=3).stdout
        except Exception:
            return ""
    return pick(parse_monitors(xrandr("--query"), xrandr("--listmonitors")), root.winfo_screenwidth(), root.winfo_screenheight())


root.update_idletasks()
mx, my, mw, mh = primary_monitor()
root.geometry("+%d+%d" % (mx + (mw - root.winfo_reqwidth()) // 2, my + (mh - root.winfo_reqheight()) // 2))
root.attributes("-topmost", True); root.lift(); root.focus_force()
(pe if a.user else ue).focus_set()
root.mainloop()
